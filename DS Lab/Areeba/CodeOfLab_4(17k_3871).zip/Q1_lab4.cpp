#include<iostream>
using namespace std;
class Node
{
	public:
	Node *next;
	int data;
	Node()
	{
		
	}
	Node(int d){
		next=new Node();
		data=d;
	}
	
};
class SLList
{
	private:
		Node *head;
		
	public:
	 int data;
		void insert( int x)
		{
			Node *newptr=new Node(x);
			if(head==NULL)
			{
				cout<<"\ninitial node "<<x<<endl;
				head=newptr;
			}
			else
			{
			    newptr=head;
				newptr->next=head;
				//head->next=head;
				head=newptr;
			}
			head->next=newptr->next;
		}
		int getdata(int y)
		{
			data=y;
		}
		void CountTest();
       SLList BuildOneTwoThree();
};
SLList SLList::BuildOneTwoThree()
	{
		int node;
		cout<<"Enter How Many Nodes You Want to Enter ";
		cin>>node;
		cout<<"Enter "<<node<<" Nodes";
		int nNode;
		for(int i=0;i<node;i++)
		{
			cout<<endl<<"Enter "<<i+1<<" Node\n";
			cin>>nNode;
			insert(nNode);
			getdata(nNode);
			
		}
		cout<<"Nodes Inserted!\n";
	    return (*this);
	}
int Count(SLList* head, int search_For) 
{
	for(int i=1;i<head->getdata(i);i++)
	{
		if(search_For==head->data)  
		{
			return search_For;
		}
	}
}
void SLList::CountTest() { 
SLList myList = BuildOneTwoThree(); // build {1, 2, 3}

int count = Count(&myList, 2); // returns 1 since there's 1 '2' in the list
cout<<"There's "<<count<<" Repeat In The SLList";
}

int main()
{
	SLList obj;
	obj.CountTest();
	return 0;
}
