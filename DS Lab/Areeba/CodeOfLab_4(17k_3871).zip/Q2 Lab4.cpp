#include<iostream>
#include<stdlib.h>
using namespace std;
class MyNode
{		
	public:
		int data,count;
		MyNode *next,*head;
		MyNode():data(0),count(0){}
		void insert(MyNode* current,int x)
		{
		    head = current;
		    data=x;
		    while(current->next != head) {
		        current = current->next;
		    }
		    current->next = head;
		    current = current->next;
		    current->data = data;
		    current->next = head;
		}
		void setdata(int d)
		{  
		    data=d;
		}
		int GetNth(MyNode* h, int index)
		{
			head=h;
			MyNode *temp=new MyNode[index];
            for(int i=0;i<head->data;i++)
            {
			}
		}
		void GetNthTest();
       MyNode BuildOneTwoThree();
};
MyNode MyNode::BuildOneTwoThree()
	{
		
		MyNode *head = (MyNode *)malloc(sizeof(MyNode));
		head->next=head;
		int index;
		cout<<"Enter the Number of Elements in the List ";
		cin>>index;
		int MyNode;
		cout<<endl<<"Enter "<<index<<" Elements in the List :\n"<<endl;
		for(int i=0;i<index;i++)
		{
			cin>>MyNode;
			setdata(MyNode);
			insert(head,MyNode);
			
		}
	
		return (*this);
	}
void MyNode::GetNthTest(){ 
MyNode myList = BuildOneTwoThree(); //

int LastNode = GetNth(&myList, 2); //
cout<<"Last MyNode "<<LastNode;
}
int main()
{
	MyNode obj;
	obj.GetNthTest();
	return 0;
}
