#include<iostream>
#include<cstring>
using namespace std;

class myNode
{
	public:
	string data;
	myNode *prev;
	myNode *next;
};
class DoublyLinkedList
{
	myNode *head;
    myNode *tail;
	public:
		DoublyLinkedList():head(0),tail(0){}      // Default Constructor
		DoublyLinkedList(const DoublyLinkedList &rhs)  // Copy Constructor
		{
			myNode *newNode,*current;
			current=rhs.head;
			this->head=0;
			myNode *last=0;
			while(current!=NULL)
			{
				if(head==NULL)
				{
					head=newNode;
					last=head;
				}
				else
				{
					last->next=newNode;
					last=newNode;
				}
				current=current->next;
			}
		}
		DoublyLinkedList &operator=(const DoublyLinkedList &rhs)   // Assignment Operator
		{
			myNode *newNode,*current;
			current=rhs.head;
			this->head=0;
			myNode *last=0;
			if(this!=&rhs)
			{
				deletelist();
				while(current!=NULL)
			{
				if(head==NULL)
				{
					head=newNode;
					last=head;
				}
				else
				{
					last->next=newNode;
					last=newNode;
				}
				current=current->next;
			}
			}
			return (*this);
		}
		~DoublyLinkedList()     // Destructor
		{
			deletelist();
			head=0;
		}
		void deletelist()     // Delete All
		{
		 	myNode *temp;
		 	temp=head;
		 	while(temp->next!=NULL)
		 	{
		 		head=head->next;
		 		temp->next=NULL;
		 		delete temp;
		 		temp=head;
			}
		}
		void insert(string x)       // Insert At Last and Front Both Are Defined
		{
			myNode *temp=new myNode();
			if(temp==NULL)
			{
                cout<<"no myNode ";
			}
			else
			{
				temp->data=x;
				if(head==NULL)
				{
					temp->next=NULL;
					temp->prev=NULL;
					head=temp;
				}
				else
				{
//					temp->next=head;                // For Front
//					head->prev=temp;
//					head=temp;
					tail=head;       
					while(tail->next!=NULL)
					{
						tail=tail->next;
					}
					tail->next=temp;
					temp->prev=tail;
					temp->next=NULL;
				}
			}
		}
		void displayFunc()
		{
			myNode *temp=new myNode();
			temp=head;
			cout<<"list is ";
			while(temp!=NULL)
			{
				cout<<" "<<temp->data;
				temp=temp->next;
			}
		}
		void findHijectedAndMember()     
		{
			myNode *temp;
			temp=head;
			int i=0;
			string s="hijected";
			string mem="member";
			while(temp!=NULL)  // To Find Hijected in the given List
			{
				if(temp->data==s)
				{
					cout<<endl<<"("<<temp->data<<")"<<" founded! At Cabin No:"<<i+1<<endl;
					break;
				}
				i++;
				temp=temp->next;
			}
			int j=1;
			while(temp->next!=NULL){
				j++;
				temp=temp->next;
			}
			j++;
			cout<<"("<<temp->data<<")"<<" is Founded At The Index Of "<<j+1;
		}
};
int main()
{
	DoublyLinkedList obj;
   string s1="hackerRank";
   string s2="hacker";
   string s3="hijected";
   string s4="Dump";
   string s5="member";
    obj.insert(s1);
    obj.insert(s2);
    obj.insert(s3);
    obj.insert(s4);
    obj.insert(s5);
	obj.displayFunc();
	obj.findHijectedAndMember();
	return 1;
}
