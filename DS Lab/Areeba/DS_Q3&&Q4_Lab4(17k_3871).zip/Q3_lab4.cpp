#include<iostream>
#include<cstring>
using namespace std;
class Node
{
	public:
	string data;
	Node *prev;
	Node *next;
};
class myDLL
{
	Node *head;
    Node *tail;
	public:
		myDLL():head(0),tail(0){}   
		myDLL(const myDLL &rhs)
		{
			Node *newNode,*current;
			current=rhs.head;
			this->head=0;
			Node *last=0;
			while(current!=NULL)
			{
				if(head==NULL)
				{
					head=newNode;
					last=head;
				}
				else
				{
					last->next=newNode;
					last=newNode;
				}
				current=current->next;
			}
		}
		myDLL &operator=(const myDLL &rhs){
			Node *newNode,*current;
			current=rhs.head;
			this->head=0;
			Node *last=0;
			if(this!=&rhs)
			{
				deletelist();
				while(current!=NULL)
			{
				if(head==NULL)
				{
					head=newNode;
					last=head;
				}
				else
				{
					last->next=newNode;
					last=newNode;
				}
				current=current->next;
			}
			}
			return (*this);
		}
		~myDLL()     // Destructor
		{
			deletelist();
			head=0;
		}
		void deletelist()     // Delete All
		{
		 	Node *temp;
		 	temp=head;
		 	while(temp->next!=NULL)
		 	{
		 		head=head->next;
		 		temp->next=NULL;
		 		delete temp;
		 		temp=head;
			}
		}
		void insert(string x)       // Insert At Last and Front Both Are Defined
		{
			Node *temp=new Node();
			if(temp==NULL)
			{
                cout<<"no node ";
			}
			else
			{
				temp->data=x;
				if(head==NULL)
				{
					temp->next=NULL;
					temp->prev=NULL;
					head=temp;
				}
				else
				{
//					temp->next=head;                // For Front
//					head->prev=temp;
//					head=temp;
					tail=head;       
					while(tail->next!=NULL)
					{
						tail=tail->next;
					}
					tail->next=temp;
					temp->prev=tail;
					temp->next=NULL;
				}
			}
		}
		void print()           // To Print List
		{
			Node *temp=new Node();
			temp=head;
			cout<<"list is ";
			while(temp!=NULL)
			{
				cout<<" "<<temp->data;
				temp=temp->next;
			}
		}
		void findHijectedAndMember()      // To Find HIJECTED and MEMBER   
		{
			Node *temp;
			temp=head;
			int i=0;
			string s="hijected";
			string mem="member";
			while(temp!=NULL)  // To Find Hijected in the given List
			{
				if(temp->data==s)
				{
					cout<<endl<<"("<<temp->data<<")"<<" founded! At Cabin No:"<<i+1<<endl;
					break;
				}
				i++;
				temp=temp->next;
			}
			int j=1;
			while(temp->next!=NULL)   // To Start Finding Last Member
			{
				j++;
				temp=temp->next;
			}
			j++;
			cout<<"("<<temp->data<<")"<<" is Founded At The Index Of "<<j+1;
		}
};
int main()
{
	myDLL obj;
   string s1="hackerRank";
   string s2="hacker";
   string s3="hijected";
   string s4="Dump";
   string s5="member";
    obj.insert(s1);
    obj.insert(s2);
    obj.insert(s3);
    obj.insert(s4);
    obj.insert(s5);
	obj.print();
	obj.findHijectedAndMember();
	return 1;
}
