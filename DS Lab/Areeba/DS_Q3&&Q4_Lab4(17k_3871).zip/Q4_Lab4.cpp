#include<iostream>
using namespace std;
class Node  
{
	public:
		int data;
		Node *next;
	Node():data(0),next(0){
	}
};
class CLL
{
	private:
		Node *head;
	public:
		CLL():head(0){}
		CLL(const CLL &rhs)
		{
			Node *newNode,*current;
			current=rhs.head;
			this->head=0;
			Node *last=0;
			while(current!=NULL)
			{
				if(head==NULL)
				{
					head=newNode;
					last=head;
				}
				else
				{
					last->next=newNode;
					last=newNode;
				}
				current=current->next;
			}
		}
		CLL &operator=(const CLL &rhs)   // Assignment Operator
		{
			Node *newNode,*current;
			current=rhs.head;
			this->head=0;
			Node *last=0;
			if(this!=&rhs)
			{
				deletelist();
				while(current!=NULL)
			{
				if(head==NULL)
				{
					head=newNode;
					last=head;
				}
				else
				{
					last->next=newNode;
					last=newNode;
				}
				current=current->next;
			}
			}
			return (*this);
		}
		~CLL()     // Destructor
		{
			deletelist();
			head=0;
		}
		void deletelist()     // Delete All
		{
		 	Node *temp;
		 	temp=head;
		 	while(temp->next!=NULL)
		 	{
		 		head=head->next;
		 		temp->next=NULL;
		 		delete temp;
		 		temp=head;
			}
		}
		void insert(int x)          // Insert Node for Both ( Front as well as Last)
		{
			Node *temp=new Node();
			Node *last;
			if(temp==NULL)
			{
				cout<<"Node Not insert";
			}
			else
			{
				temp->data=x;
				if(head==NULL)
				{
					head=temp;
					temp->next=head;
				}
				else
				{
					last=head;
					while(last->next!=head)
					{
						last=last->next;
					}
					last->next=temp;
					temp->next=head;
					//head=temp;                //If we remove this comment then List is insert At Front
				}
			}
		}
		void DeleteNodeAtFront()    // Delete At Front
		{
			Node *temp=head;
            if(head==NULL)
            {
            	head=NULL;
            	delete head;
			}
			else if(head->next==head)
			{
				head=NULL;
				delete head;
			}
			else
			{
				temp=head;
				while(temp->next!=head)
				{temp=temp->next;
				}
				temp->next=head->next;
				delete head;
				head=temp->next;
			}
			
		}
		void DeleteNodeAtLast()    // Delete At Last
		{
			Node *temp=head;
			Node *last;
            if(head==NULL)
            {
            	head=NULL;
            	delete head;
			}
			else
			{
				last=head;
				while(last->next!=head)
				{
					temp=last;
				   last=last->next;
				}
				temp->next=head;
				last->next=NULL;
				temp=head;
				delete last;
			}
		}
		void Search()           // To Search Node
		{
			Node *temp=head;
			int n,i=0;
			cout<<"\nEnter the element \n";
			cin>>n;
			while(temp->next!=NULL)
			{
				if(temp->data==n)
				{
					cout<<"Found At The Location Of "<<i+1;
					break;
				}
				i++;
				temp=temp->next;
			}
		}
		void print()
		{
			Node *temp=head;
			cout<<"\nList is  ";
			while(temp->next!=head){
				cout<<" "<<temp->data;
				temp=temp->next;
			}
			cout<<" "<<temp->data;
		}
};
int main() 
{
	CLL obj;
	int choice;
	obj.insert(2);
	obj.insert(3);
	obj.insert(4);
	obj.insert(6);
	cout<<"\nSelect The Following List "<<endl<<"1.Search\n2.DeleteAtFront\n3.DeleteAtLast\n4.Print\n";
	cin>>choice;
	switch(choice)
	{
		case 1:
			obj.print();
			obj.Search();
			break;
		case 2:
			obj.print();
			obj.DeleteNodeAtFront();
			cout<<"\nAfter the Delete Node from Front New List is ";
			obj.print();
			break;
		case 3:
			obj.print();
			obj.DeleteNodeAtLast();
			cout<<"\nAfter the Delete Node from Last New List is ";
			obj.print();
			break;
		case 4:
			obj.print();
			break;
		default:
			cout<<"InValid Number! ";
	}
	return 1;
}
