#include<iostream>
#include <bits/stdc++.h>
using namespace std;
class student
{
	private:
		char ptr[10][20];
		int size;
		char temp[20];
	public:
		student()
		{
			ptr[0][0]='0';
		}
		student(int n){
			size=n;

		}
		void DescendingOrder(int n)
		{
			size=n;
			cout<<"Enter "<<size<<" Names :"<<endl;
			for(int i=0;i<size;i++)
			{
				
				cin>>ptr[i];
			}
			for(int i=1;i<size;i++)
			{
			   for(int j=1;j<size;j++)
			   {
			   	 	if(strcmp(ptr[j],ptr[j-1])<0){
			   			strcpy(temp , ptr[j]);
			   			strcpy(ptr[j] , ptr[j-1]);
			   			strcpy(ptr[j-1],temp);
					   }
			   }
			}
			cout<<endl<<"DescendingOrder is :"<<endl;
			for(int i=size;i>=0;i--)
			{
				cout<<endl;
				cout<<ptr[i]<<" ";
			}
		}
};

main()
{
	student *std;
	std=new student[5];
	std->DescendingOrder(5);
}
