#include<iostream>
using namespace std;
class Employee
{
	private:
		int *age;
		int *hour;
		int *experienced;
		int hourWage;
		double Salary;
	public:
		Employee()
		{
			age=new int;
			hour=new int;
			experienced=new int;
			age=0;
			hour=0;
			experienced=0;
			hourWage=0;
		}
		Employee(int *a,int *h,int *e)
		{
			hourWage=0;
			age=new int;
			hour=new int;
			experienced=new int;
			experienced=e;
			age=a;
			hour=h;
			if(*age>50||*age<=50||*age<=40||*age<=30)
		  {
			if(*age>50)
			{
				if(*experienced>10&&*hour>240)
				{
					hourWage=500;
					Salary=hourWage*(*hour);
					cout<<"Salary :"<<Salary<<endl<<endl;
				}
			}
			else if(*age<=50)
			{
				if(*age>40)
				{
					if(*experienced<=10&&*experienced>6&&*hour>200&&*hour<=240)
					{
						hourWage=425;
						Salary=hourWage*(*hour);
						cout<<"Salary :"<<Salary<<endl<<endl;
					}
				}
				
			}
			else if(*age<=40)
			{
				if(*age>30)
				{
					if(*experienced<=6&&*experienced>3&&*hour>160&&*hour<=200)
					{
						hourWage=375;
					    Salary=hourWage*(*hour);
						cout<<"Salary :"<<Salary<<endl<<endl;
					}
				}
				
			}
			else if(*age<=30)
			{
				if(*age>22)
				{
					if(*experienced<=3&&*experienced>1&&*hour>120&&*hour<=160)
					{
						hourWage=300;
						Salary=hourWage*(*hour);
						cout<<"Salary :"<<Salary<<endl<<endl;
					}
				}

			}
		  }
			else
			{cout<<"invalid Parameters ";
			}
			
		}
		void setAge(int *a)
		{
			age=new int;
			age=a;
		}
		void setHour(int *h)
		{
			hour=new int;
			hour=h;
		}
		void setExperienced(int *e)
		{
			experienced=new int;
			experienced=e;
		}
		int getAge()const
		{return *age;
		}
		int getHour()const
		{return *hour;
		}
		int getExperienced()const
		{return *experienced;
		}
		
};

main()
{
	int NumberOfEmployee,*age,*hour,*experienced;
	age=new int;
	hour=new int;
	experienced=new int;
	cout<<"Enter the Number of Emplyee :";
	cin>>NumberOfEmployee;
	for(int i=1;i<=NumberOfEmployee;i++)
	{
		cout<<"Employee :"<<i<<endl;
		cout<<"\nFollowing Parameters Are Valid :\n1.Age>50 Hours>240 Experienced>10\n2.Age>40&&<=50 Hour>200&&<=240 Experienced<=10&&>6"
		"\n3.Age>30&&<=40 Hour>160&&<=200 Experienced<=6&&>3\n4.Age>22&&<=30 Hour>120&&<=160 Experienced<=3&&>1\n";
		cout<<"\nEnter Age,Hours and Experienced ";
		cin>>*age>>*hour>>*experienced;
		Employee obj(age,hour,experienced);
	}

	
}
