#include<iostream>
using namespace std;



class MaxHeap
{
	private:
	int *arr;      
	int space;
	int size;
	public:
	MaxHeap(int space)
    {
		arr = new int[space];
		this->space = space;
		this->size = 0;
	}
	void insert(int k)
    {
		arr[size] = k;
		siftup(size);
		size++;
		for(int i = 0;i<size;i++){
		   cout<<arr[i]<<" ";
		}
		cout<<endl;
	}
	int getSize()
    {
	  return size;
	}
	int getparent(int child)
	
	{
		if(child%2==0)
		return (child/2)-1;
		else
		return (child/2);
	}
	int getleft(int parent)
	{
		return (2*parent+1);
		
	}
	int getright(int parent)
	{
		return (2*parent+2);
	}
   int getMax()
    {
	  for(int i = 0;i<size;i++)
		{
		  cout<<arr[i]<<" ";
		}
     cout<<endl;
     return arr[0];

	}
	bool isleaf(int i)
	{
		if(i>=size)
        return true;
        return false;
	}
	void siftup(int i)
	{
	   if(i == 0)
		return;
		int parent_index = getparent(i);
		if(arr[parent_index] <arr[i])   {
			int temp = arr[parent_index];
			arr[parent_index] = arr[i];
			arr[i] = temp;
			siftup(parent_index);
		}
		
	}
	void siftdown(int i)
	{
		
		int l = getleft(i);
		int r = getright(i);
		if(isleaf(l))
		return;	
		int maxIndex = i;
		if(arr[l] >arr[i]){
			maxIndex = l;
		}
		if(!isleaf(r) && (arr[r] >arr[maxIndex])){
			maxIndex = r;
		}
		if(maxIndex != i){
			int temp = arr[i];
			arr[i] = arr[maxIndex];
			arr[maxIndex] = temp;
			siftdown(maxIndex);
		}
	}	
   
	int extractMax()
		{
			int max = arr[0];
			arr[0] = arr[size - 1];
			
			size--;
			
			siftdown(0);
			cout<<"\n\nMax Value :"<<max;
			return max;
		}
	int removeAt(int K)
		{
			int r = arr[K];
			
			arr[K] = arr[size -1];  // replace with rightmost leaf 
			size-- ;
			int p = getparent(K);
			if(K == 0 || arr[K] <arr[p])
			siftdown(K);
			else
			siftup(K);
			cout<<"\n\nRemoved Value :"<<r;
			return r;   
		}
    void heapify(int *array, int len)
    	{
		
			size = len;
			arr = array;
			
			for(int i=size-1; i>=0; --i)
			{
				siftdown(i);
			}
		}
};
int main()
{
	MaxHeap obj(6);
		
	obj.insert(6);
	obj.insert(67);
	obj.insert(89);
	obj.insert(23);
	obj.insert(45);
	obj.removeAt(3);
	obj.extractMax();
	
	return 0;
	
	
}


