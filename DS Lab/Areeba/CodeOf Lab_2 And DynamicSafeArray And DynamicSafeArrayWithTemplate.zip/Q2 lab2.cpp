#include<iostream>
using namespace std;
int main()
{
	int ArrSize,element;
	cout<<"Enter Rows :"<<endl;
	cin>>ArrSize;
	int *ptr[ArrSize],matrix[ArrSize];
	for(int i=0;i<ArrSize;i++){
		cout<<"Enter Number of Elements : "<<i+1<<endl;
		cin>>element;
		ptr[i]=new int [element];
		matrix[i]=element;
		cout<<endl<<"Enter "<<element<<"Elements :\n"<<endl;
		for(int j=0;j<element;j++){
			cin>>ptr[i][j];
		}
	}
	for(int i=0;i<ArrSize;i++){
		cout<<endl;
		for(int j=0;j<matrix[i];j++){
			cout<<ptr[i][j]<<" ";
		}
	}
	return 0;
}
