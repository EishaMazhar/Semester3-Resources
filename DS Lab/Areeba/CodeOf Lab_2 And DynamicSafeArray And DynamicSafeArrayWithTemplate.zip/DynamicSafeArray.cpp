#include<iostream>
#include <bits/c++config.h>
using namespace std;
class DynamicSafeArray
{
	private:
		int *data;
		int size;
	public:
		DynamicSafeArray(){
			size=0;
			this->data=new int[size];
		}
		DynamicSafeArray(int s){
			size=s;
			this->data=new int[size];
		}
		DynamicSafeArray(const DynamicSafeArray&obj){
			this->size=obj.size;
			this->data=new int [this->size];
		}
		DynamicSafeArray operator=(const DynamicSafeArray& obj){
			if (this == &obj)
			 return *this;
			 delete[] data;
			
			 size = obj.size;
			 data = new int[size];
			 return *this; 
		}
		const int & operator[](int i)const{
			if(i<0||i>size-1){
				cout<<"Boundary Error ";
				exit(1);
			}
			return data[i];
		}
		~DynamicSafeArray(){
			if(data!=0)
			{
				delete[]data;
				data=0;
				size=0;
			}
		}
void Resize (int nsize)
{
	if(size<nsize)
	{
		int *temp;
		temp=new int[size];
		for(int i=0;i<size;i++)
		{
			temp[i]=data[i];
		}
		delete[]data;
		data=new int[nsize];
	}
}
		
		friend ostream& operator<<(ostream &out, DynamicSafeArray &obj);
		friend istream& operator>>(istream &in,DynamicSafeArray &obj);
};

ostream& operator<<(ostream &out,DynamicSafeArray &obj)
{
	int n=obj.size;
	cout<<endl<<"Elements Are :";
	for(int i=0;i<n;i++)
	{
		out<<endl<<obj.data[i];
	}
}
istream& operator>>(istream &in,DynamicSafeArray &obj)
{
	int n=obj.size;
	cout<<endl<<"Enter Elements "<<endl;
	for(int i=0;i<n;i++)
	{
		in>>obj.data[i];
	}
}

main()
{
	int nsize=10;
	DynamicSafeArray obj1,obj2(5);
	DynamicSafeArray obj3(obj2);
	obj2.Resize(nsize);
	operator>>(cin,obj2);
	operator<<(cout,obj2);
	obj3=obj2;
	cout<<endl<<obj2[2];
}
