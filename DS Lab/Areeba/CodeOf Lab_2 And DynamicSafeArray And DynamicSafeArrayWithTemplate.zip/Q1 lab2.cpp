#include<iostream>
using namespace std;
void desOrder(int size, int array[])
{
	int i,j,temp;
	int *ptr2;
	ptr2=new int[10];
	cout<<endl<<"Descending Order "<<endl;
	for(i=0;i<size;i++)
	{
		ptr2[i]=array[i];
	}
	for(i=0;i<size;i++)
	{
		for(j=i+1;j<size;j++)
		{
		if(ptr2[i]<ptr2[j])
		{
			temp=ptr2[i];
			ptr2[i]=ptr2[j];
			ptr2[j]=temp;
		}
		}
		
	}
	for(i=0;i<size;i++)
	{
		cout<<endl;
		cout<<ptr2[i];
	}
}
void acdOrder(int size,int array[])
{
	int i,j,rows,col;
	int *ptr1;
	ptr1=new int[10];
	cout<<"Enter the ELements "<<endl;
	for(i=0;i<size;i++)
	{
	    cin>>array[i];
	}
	for(i=0;i<size;i++)    //For Not Change the Original Array
	{
	    ptr1[i]=array[i];
	}
	int temp;
	cout<<endl<<"Ascending Order "<<endl;
	for(i=0;i<size;i++)
	{
		for(j=i+1;j<size;j++){
			if(ptr1[i]>ptr1[j]){
				temp=ptr1[i];
				ptr1[i]=ptr1[j];
				ptr1[j]=temp;
			}
		}
		
	}
	for(i=0;i<size;i++)
	{
		cout<<endl;
		cout<<ptr1[i];
	}
}

int main()
{
	int array[10];
	acdOrder(10,array);
	desOrder(10,array);
}
