#include<iostream>
using namespace std;
void BubleSort(int array[],int nsize)
{
	int i,j,temp;
	bool flag=0;
	for(i=0;i<nsize;i++){
		cout<<"\nIteration Pass "<<i+1<<"\n";
		for(j=i+1;j<nsize;j++){
			if(array[i]>array[j]){
				temp=array[i];
				array[i]=array[j];
				array[j]=temp;
				flag=true;
			}
		}
		if(flag==false){
		  break;
		}
	}
	if(flag==true)
	{
		cout<<"\nArray is Not Already Sorted ";
		cout<<endl<<"Sorted Array ";
		for(i=0;i<nsize;i++)
		{
			cout<<"\n"<<array[i];
		}
	}
	else{
		cout<<"Array is  Already Sorted ";
		cout<<endl<<"Sorted Array ";
		for(i=0;i<nsize;i++)
			cout<<"\n"<<array[i];}
		

}
int main()
{
	int i,size;
	cout<<"Enter the Number of elements ";
	cin>>size;
	cout<<"Enter  "<<size<<" Elements ";
	int array[size];
	for(i=0;i<size;i++){
		cin>>array[i];
	}
    BubleSort(array,size);
    return 0;
}
