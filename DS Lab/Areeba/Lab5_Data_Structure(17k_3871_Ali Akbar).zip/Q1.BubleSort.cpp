#include<iostream>
using namespace std;
class bubbleClass
{
	private:
		int i,j,temp;
	public:
		bubbleClass()
		{
		}
	void BubleSort(int array[],int nsize)
	{
		for(i=0;i<nsize;i++)
		{
			cout<<"Itration Pass "<<i+1<<"\n";
			for(j=i+1;j<nsize;j++)
			{
				if(array[i]>array[j])
				{
					cout<<array[i]<<endl;
					temp=array[i];
					array[i]=array[j];
					array[j]=temp;
				}
			}
		}
		cout<<endl<<"Sorted Array is ";
		for(i=0;i<nsize;i++)
		{
			cout<<"\n"<<array[i];
		}
	}
};

int main()
{
	int i,size;
	bubbleClass b;
	cout<<"Enter Number of elements :";
	cin>>size;
	cout<<"Enter  "<<size<<" Elements :\n";
	int array[size];
	for(i=0;i<size;i++)
		cin>>array[i];
	b.BubleSort(array,size);
}
