#include<iostream>
using namespace std;
void SelectionSort(int array[],int size)
{
	int i,j;
	int index,small;
	for(i=0;i<size;i++)
	{
		small=array[i];
		index=i;
		for(j=i+1;j<size;j++)
		{
			if(array[j]>small)
			{
				small=array[i];
				array[i]=array[j];
				array[j]=small;
				index=j;
			}
		}
	}
	cout<<"Sorted Array In Descendong Order is \n";
	for(i=0;i<size;i++)
	{
		cout<<array[i]<<endl;
	}
}
int main()
{
	int array[5]={1,2,3,4,5};
	SelectionSort(array,5);
	return 0;
}
