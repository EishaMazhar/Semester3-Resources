#include<iostream>
using namespace std;
void charBubbleSort(char *arr,int size)
{
	int i,j;
	char temp;
	for(i=0;i<size;i++)
	{
		for(j=i+1;j<size;j++)
		{
			if(arr[i]>arr[j])
			{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	cout<<"Sorted Characters Are ";
	for(i=0;i<size;i++)
		cout<<"\n"<<arr[i];
}
int main()
{
	int size,i;
	cout<<"Enter the Size of Array ";
	cin>>size;
	char array[size];
	cout<<"Enter "<<size<<" Characters \n";
	for(i=0;i<size;i++)
	{
		cin>>array[i];
	}
	charBubbleSort(array,size);
	return 0;
}
