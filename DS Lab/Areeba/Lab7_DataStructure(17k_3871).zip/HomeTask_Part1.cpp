#include<bits/stdc++.h>
#include<windows.h>
using namespace std;
class Sorting
 {
 public:

void merge(int a[], const int low, const int mid, const int high)
{ 
        int * b = new int[high+1-low];
        int h,i,j,k;
        h=low;
        i=0;
        j=mid+1;

        while((h<=mid)&&(j<=high))
        {
                if(a[h]<=a[j])
                {
                        b[i]=a[h];
                        h++;
                }
                else
                {
                        b[i]=a[j];
                        j++;
                }
                i++;
        }
        if(h>mid)
        {
                for(k=j;k<=high;k++)
                {
                        b[i]=a[k];
                        i++;
                }
        }
        else
        {
                for(k=h;k<=mid;k++)
                {
                        b[i]=a[k];
                        i++;
                }
        }
        k=0;
        while(k<=high-low) 
        {
                a[k+low]=b[k];
                k++;
                
        }
        delete[] b;
}
void Print(int a[],int b,int c)
{
      for(int k=b;k<=c;k++) 
        {
               cout<<a[k]<<endl;
                
        }
}
void quick_sort(int data[], int low, int high)
{
	Sleep(1);
    int i = low;
    int j = high;
    int pivot = data[low + ((high - low)/2)];
	while (i <= j)
      {
		while (data[i] < pivot) i++;
		while (data[j] > pivot) j--;
		if (i <= j) 
            {
			swap(data[i],data[j]);
			i++;
			j--;
		}
		i++;
	 }
   if (low < j)
	quick_sort(data, low, j);
   if (i < high)
	quick_sort(data, i, high);
}     
void merge_sort(int a[], const int low, const int high)// Recursive 
{
	Sleep(1);
        int mid;
        if(low<high)
        {
                mid=(low+high)/2;
                merge_sort(a, low,mid);
                merge_sort(a, mid+1,high);
                merge(a, low,mid,high);
        }
}
};
class shellsort
{
private:
        int no_of_elements;
        int *elements;
        public:
               void getarray(fstream& fout);
               void sortit(int [],int);
               int return_no_elements();
               void print();

};
void shellsort::getarray(fstream& infile)
{
     infile>>no_of_elements;
    elements=new int[no_of_elements];
     for(int i=0;i<no_of_elements;i++)
     {
       infile>>elements[i];
     }
}
int shellsort:: return_no_elements()
{
return no_of_elements;
}
void shellsort::sortit(int inc[],int incnum)
{
	Sleep(1);
int incr,j,k,span, y;
for(incr=0;incr<incnum;incr++)
{
span=inc[incr];
for(j=span;j<no_of_elements;j++)
{
y=elements[j];
for(k=j-span;k>=0&& y<elements[k]; k-=span)
{
                     elements[k+span]=elements[k];
                     }
elements[k+span]=y;
}
cout<<"iteration= "<<incr+1<<"span = "<<span<<" : ";
print();
if(span==1)
break; 
}
}
void shellsort:: print()
{
for(int i=0;i<no_of_elements;i++)
{
cout<<elements[i]<<" ";
}
cout<<endl;
}
class radixsort{
    int *arr,n;
    public:

void  getdata(fstream& infile)
{
    infile>>n;
    arr=new int[n];
    for(int i=0;i<n;i++)
        infile>>arr[i];
}
void showdata()
{
    cout<<"\n--Display--\n";
    for(int i=0;i<n;i++)
        cout<<arr[i]<<"   ";
}

void  sortLogic()
{
	Sleep(1);
    int bucket[10][20], buck_count[10], b[10];
    int i,j,k,r,no_of_passes=0,divisor=1,largest,pass_no;
    largest=arr[0];
    for(i=1;i<n;i++)  
    {
        if(arr[i] > largest)
            largest=arr[i];
    }
    while(largest > 0)  
    {
        no_of_passes++;
        largest /= 10;
    }

    for(pass_no=0; pass_no < no_of_passes; pass_no++)
	{

        for(k=0; k<10; k++)
        {
          buck_count[k]=0; 
        
		}
		for (i=0 ; i<n ; i++)
          {
		    r=(arr[i]/divisor) % 10;
            bucket[r][buck_count[r]++]=arr[i];
        }
        i=0; 
        for (k=0;k<10;k++)
		    for(j=0; j<buck_count[k]; j++)
                arr[i++] = bucket[k][j];
        divisor*=10;
    }
}
};
int main()
{
	double clock1,clock2;
	fstream infile;          //For Input and Output
	infile.open("inputfile.txt",ios::out | ios::trunc);
	int *mergesort;
	int *quicksort,size;
	
	Sorting s;
	shellsort sh;
	radixsort rs;
	cout<<"Enter the size of array :"; 
	cin>>size;
	mergesort=new int[size];
    quicksort=new int[size];
    
   infile<<size<<endl;    // File Is USed For OutPut
    srand(time(0));
    for(int i=1;i<=size;i++)
    {
    	infile<<rand()%(200-1+1)+1<<endl;
	}
	infile.close();
    infile.open("inputfile.txt",ios::in);
    for(int i=0;i<size;i++)
    {
     infile>>mergesort[i];
	}
	infile.close();
	infile.open("inputfile.txt",ios::in);
    for(int i=0;i<size;i++)
    {
    	infile>>quicksort[i];
	}
	infile.close();
	
	infile.open("inputfile.txt",ios::in);
	sh.getarray(infile);
	infile.close();
	
	infile.open("inputfile.txt",ios::in);
	rs.getdata(infile);
	infile.close();
	
	clock1=clock();
	rs.sortLogic();
	clock2=clock();
	
	cout<<"Time of sort is :"<<(clock2-clock1)/CLOCKS_PER_SEC<<endl;
	cout<<"Sorting result"<<endl<<endl;
	rs.showdata();
	cout<<endl;
	
	cout<<endl;
	clock1=clock();
	s.merge_sort(mergesort,0,size-1);
	clock2=clock();
	cout<<"Time of sort is :"<<(clock2-clock1)/CLOCKS_PER_SEC<<endl;
	cout<<"Sorting result"<<endl<<endl;	
	s.Print(mergesort,0,size-1);
	cout<<endl;
	
	int shell[size];
	int i,j;
	for(i=size,j=0;i>0;i=i/2,j++)
	{
	shell[j]=i;
	}
	clock1=clock();
	sh.sortit(shell,j+1);
	clock2=clock();
	
	cout<<"Time of sort is :"<<(clock2-clock1)/CLOCKS_PER_SEC<<endl;
	cout<<"Sorting result"<<endl;	
	sh.print();
	cout<<endl;
	
	cout<<endl;
	clock1=clock();
	s.quick_sort(quicksort,0,size-1);
	clock2=clock();
	
	cout<<endl;
	cout<<"Time of sort is :"<<(clock2-clock1)/CLOCKS_PER_SEC<<endl;
	cout<<"Sorting result"<<endl;	
	s.Print(quicksort,0,size-1);
	cout<<endl;
	
	return 0;
}
