/*
Miss In this Programm Iam Using Template Queue
*/
#include<bits/stdc++.h>


using namespace std;

void reverse(queue<int> &q)
{
    if(q.empty())
        return ;
    int num=q.front();
    q.pop();
    reverse(q);
    q.push(num);
}

int main()
{
    int arr[]={1,4,6,8,2,5,10,12,14};
    queue<int >q;    // PreDefined Queue In Template Case
    int i=0;
    cout<<"Given Array Is :";
    while(i<9)
    {
    	cout<<arr[i]<<" ";
    	i++;
	}
	i=0;
    while(i<9)
    {
        q.push(arr[i]);
        i++;
    }
    reverse(q);
    cout<<"\nAfter Reverse The New One Is :";
    i=0;
    while(i<9)
    {
        cout<<q.front()<<" ";
        q.pop();
        i++;
    }
    return 0;
}
