#include<bits/stdc++.h>

using namespace std;
class Queue
{
	private:
		int *data;
		int front;
		int rear;
		int size;
		Queue *obj;
		void EnQueue(Queue *obj,int d);
	public:
		void EnQueue(int d)
		{
			EnQueue(obj,d);
		}
		Queue()
		{
			data=new int;
			data=0;
			front=-1;
			rear=0;
		}
		Queue(int nsize)
		{
			size=nsize;
			data=new int [size];
			rear=0;
			front=-1;
		}
		int DeQueue()
		{
			int d;
			if(!isEmpty())
			d=data[++front];
			return d;
		}
		int Size()
		{return size;
		}
		bool isFull()
		{
			if(rear==size)
			return true;
			else
			return false;
		}
		bool isEmpty()
		{
			if(front==-1)
			return true;
			else
			return false;
		}
		void Print()
		{
			for(int i=0;i<size;i++)
			{
				cout<<data[i]<<" ";
			}
		}
		int Front()
		{
			return data[++front];
		}
};
void Queue::EnQueue(Queue *obj,int d)
{
	if(!isFull())
	data[rear++]=d;
	else
	cout<<"\nQueue is Full :";
}
int main()
{
	Queue obj(4);
	obj.EnQueue(5);
	obj.EnQueue(3);
	obj.EnQueue(8);
	obj.EnQueue(9);
	cout<<"Queue is :";
	obj.Print();
	cout<<"\nFront Element is :";
	cout<<obj.Front();
	return 0;
}
