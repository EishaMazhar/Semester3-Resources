#include<bits/stdc++.h>
using namespace std;
class Node
{
	public:
    int data;
    Node *next;
}*node;
class Queue
{
	public:
    int count;
     Node *front;
     Node *rear;
    
}*queueq;
void Create_Queue()
{
    queueq=new Queue;
    queueq->count=0;
    queueq->front=NULL;
    queueq->rear=NULL;
}
void Create_Node(){
    node=new Node;
    node->next=NULL;
}
void EnQueue(int data){
    Create_Node();
    node->data=data;
    if(queueq->count==0){
        queueq->front=node;
        queueq->rear=node;
    }
    else{
        queueq->rear->next=node;
        queueq->rear=node;
    }
    queueq->count++;
}
void print(){
    Node *temp;
    temp=queueq->front;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}
void DeQueue( Node *temp){
    Node *temp1;
    temp1=temp->next;
    temp->next=temp1->next;
    free(temp1);
    temp=temp->next;
    queueq->count--;
}
void DeleteNegativeValues(){
    Node *temp;
    temp=queueq->front;
    while(temp->next!=NULL){
		if(temp->next->data<0)
        {
            DeQueue(temp);
        }
        else
        {
            temp=temp->next;
        }
    }
}


int main()
{
    Create_Queue();
    EnQueue(34);
    EnQueue(45);
    EnQueue(18);
    EnQueue(659);
    EnQueue(-72);
    cout<<"\nBefore : ";
    print();
    DeleteNegativeValues();
    cout<<"\nAfter : ";
    print();
    cout<<endl;
    return 0;
}
