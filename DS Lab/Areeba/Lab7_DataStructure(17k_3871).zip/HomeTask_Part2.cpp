#include<bits/stdc++.h>
using namespace std;
void ModifyInsertionSort(int arr[],int size)
{
	int temp,j,i=1;
	while(i<size)
	{
		temp=arr[i];
		j=i-1;
		while(j>=0&&temp<arr[j]) 
		{ 
		   arr[j+1]=arr[j]; 
		   j=j-1; 
		} 
		arr[j+1]=temp;
		i++; 
	}
}
void Quick_Sort(int data[], int left, int right)
{
    int i=left;
    int j=right;
    int pivot=data[left+((right-left)/2)];    
    if((left-right)<9) 
    {
        ModifyInsertionSort(data,left+1);
    }
	while(i<=j)
      {
		while (data[i]<pivot) 
		{
		i++;
     	}
		while (data[j]>pivot)
		{
		j--;
	    }
		if(i<=j) 
        {
		swap(data[i],data[j]);
		i++;
		j--;
		}
	 }
   if(i<right)
	Quick_Sort(data,i,right);
   if(left<j)
	Quick_Sort(data,left,j);
}
int main()
{
	int size=10;
	int arr[size]={14,167,123,02,1345,5678,47,11,61,91};
	Quick_Sort(arr,0,9);
	cout<<"After Modify Inseration Sort For Quick Sort is : "<<endl;
	for(int i=0;i<10;i++)
	{
		cout<<arr[i]<<endl;	 
	}
	return 0;
}
