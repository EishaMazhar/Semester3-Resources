#include<iostream>
using namespace std;
class shellsort
{
private:
        int no_of_elements;
        int elements[14];
        public:
               void getarray();
               void sortit(int [],int);
               int return_no_elements();
               void print();

};
void shellsort::getarray()
{
       no_of_elements=14;
//elements[14]={23,3,7,13,89,7,66,2,6,44,18,90,98,57};
     cout<<"insert Given elemet to sort:"<<endl;
     for(int i=0;i<no_of_elements;i++)
     {
       cin>>elements[i];
     }

}
int shellsort:: return_no_elements()
{
    return no_of_elements;
}
void shellsort::sortit(int inc[],int incnum)
{
   int incr,j,k,span, y;
	for(incr=0;incr<incnum;incr++)
	{
		span=3;
		for(j=span;j<no_of_elements;j++)
		{
			y=elements[j];
			for(k=j-span;k>=0&& y<elements[k]; k-=span)
			{
			    elements[k+span]=elements[k];
			}
			elements[k+span]=y;
		}
		cout<<"\niteration= "<<incr+1<<"span = "<<span<<" : ";
		print();
		if(span==3)
		break; 
	}
}
void shellsort:: print()
{
	for(int i=0;i<no_of_elements;i++)
	{
	  cout<<elements[i]<<" ";
	}
	   cout<<endl;
	}
int main()
{
	shellsort ss;
	int n,i,j;
	ss.getarray();
	n=ss.return_no_elements();
	int incrm[n];
	for(i=n,j=0;i>0;i=i/2,j++)
	{
		incrm[j]=i;
	}
ss.sortit(incrm,j+1);
//system("pause");
}

